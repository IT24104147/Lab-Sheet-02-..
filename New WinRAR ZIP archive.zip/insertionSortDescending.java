import java.util.Scanner;
public class insertionSortDescending {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number of elements: ");
        int n=sc.nextInt();

        int[] arr=new int[n];

        System.out.println("Enter "+n+"numbers for the array elements: ");
        for (int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
        insertionSortDescending(arr);

        sc.close();

        System.out.print("Sorted array in descending order: ");
        for (int num : arr){
            System.out.print(num +" ");

        }
    }
    public static void insertionSortDescending(int[] A){
        int n=A.length;
        for (int j=1;j<n;j++){
            int key = A[j];
            int i = j-1;

            while (i>=0 && A[i]>key){
                A[i+1]=A[i];
                i = i-1;

            }
            A[i+1]=key;
        }
    }
}
