import java.util.Arrays;
import java.util.Scanner;
public class InsertionSortWithShifts {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.print("Enter" + n + " numbers for the array: ");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();

        }
        int shiftCount = insertionSortDescending(arr);
        sc.close();

        System.out.println("Sorted array in descending order: " );
        for (int num:arr) {
            System.out.print(num + " ");
        }
        System.out.println("\nNumber of shifted elements: " + shiftCount);

    }
    public static int insertionSortDescending(int[] A) {
        int n = A.length;
        int shiftCount = 0;

        for (int i = 1; i < n; i++) {
            int key = A[i];
            int j = i - 1;

            while (j >= 0 && A[j] > key) {
                A[j + 1] = A[j];
                i = i - 1;
                shiftCount++;
            }
            A[j + 1] = key;

        }
        return shiftCount;
    }
}
