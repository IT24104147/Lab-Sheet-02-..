import java.util.Scanner;
public class insertionSort {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        //get user inputs
        System.out.print("Enter a number elements : ");
        int n = sc.nextByte();

        // create an array
        int [] arr = new int[n];

        //take user inputs for the array
        System.out.print("Enter "+ n + "number o array");
        for (int i  =0; i<n; i++) {
            arr[i] = sc.nextInt();

            insertionSort(arr);

        }
        sc.close();
        System.out.print("sorter arr is: ");
        for (int  num :arr){
            System.out.print(num +" ");
        }
    }

    public static void insertionSort(int [] A){
        int n = A.length;

        for(int j = 1; j<n; j++) {
            int key = A[j];
            int i = j - 1;


            //shift the value
            while (i > 0 && A[i] > key) {
                A[1 + i] = A[i];
                i = i - 1;

                // Insert key at the correct position
                A[i + 1] = key;

            }

        }
    }
}
